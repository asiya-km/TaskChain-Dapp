import { useState, useEffect } from "react";
import { getTaskChainContract, connectWallet } from "./utils/provider";
import TaskList from "./components/TaskList";
import NFTGallery from "./components/NFTGallery";

function App() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [walletConnected, setWalletConnected] = useState(false);

  // Optional: auto-connect on load
  useEffect(() => {
    connectWallet()
      .then(() => setWalletConnected(true))
      .catch(() => console.log("Wallet not connected yet"));
  }, []);

  async function handleCreateTask() {
    if (!walletConnected) return alert("Connect your wallet first!");

    try {
      const contract = await getTaskChainContract(); // ✅ await and wallet-connected
      const tx = await contract.createTask(title, description);
      await tx.wait();

      alert("Task created successfully!");
      setTitle("");
      setDescription("");
    } catch (error) {
      console.error("CreateTask failed:", error);
      alert("Failed to create task — check console for details.");
    }
  }

  return (
    <div>
      <h1>TaskChain DApp</h1>

      {/* Connect Wallet */}
      {!walletConnected && (
        <button onClick={async () => {
          try {
            await connectWallet();
            setWalletConnected(true);
          } catch (err) {
            console.error("Wallet connection failed:", err);
          }
        }}>
          Connect Wallet
        </button>
      )}

      <h2>Create Task</h2>
      <input
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        disabled={!walletConnected} // disable input until wallet connected
      />
      <input
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        disabled={!walletConnected} // disable input until wallet connected
      />
      <button onClick={handleCreateTask} disabled={!walletConnected}>
        Create Task
      </button>

      {/* Only show these if wallet is connected */}
      {walletConnected ? (
        <>
          <TaskList walletConnected={walletConnected} />
          <NFTGallery walletConnected={walletConnected} />
        </>
      ) : (
        <p>Connect wallet to load tasks and NFTs</p>
      )}
    </div>
  );
}

export default App;

