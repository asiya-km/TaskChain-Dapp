import React, { useState } from "react";
import { getTaskChainContract } from "../utils/provider";

export default function CreateTask({ onTaskCreated }) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");

  async function createTask() {
    if (!title || !desc) {
      alert("Title and Description are required");
      return;
    }

    try {
      const contract = await getTaskChainContract(); // signer connected
      const tx = await contract.createTask(String(title), String(desc));
      await tx.wait();
      alert("Task created!");

      // Optionally notify parent to reload tasks
      if (onTaskCreated) onTaskCreated();
      
      // Clear input fields
      setTitle("");
      setDesc("");
    } catch (err) {
      console.error("createTask failed:", err);
      alert("Error creating task. Check console.");
    }
  }

  return (
    <div>
      <h3>Create Task</h3>
      <input
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        placeholder="Description"
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
      />
      <button onClick={createTask}>Create Task</button>
    </div>
  );
}

