import React, { useEffect, useState } from "react";
import { getRewardNFTContract } from "../utils/provider";

export default function NFTGallery({ walletConnected }) {
  const [nfts, setNfts] = useState([]);
  const [loading, setLoading] = useState(false);

  function resolveIPFS(url) {
    if (url.startsWith("ipfs://")) {
      return url.replace("ipfs://", "https://ipfs.io/ipfs/");
    }
    return url;
  }

  async function loadNFTs() {
    if (!walletConnected) return;

    try {
      setLoading(true);
      const nftContract = await getRewardNFTContract();
      const count = await nftContract.tokenCounter();
      const nftList = [];

      for (let i = 0; i < count; i++) {
        const tokenURI = await nftContract.tokenURI(i);
        const res = await fetch(resolveIPFS(tokenURI));
        const metadata = await res.json();

        nftList.push({
          id: i,
          name: metadata.name,
          description: metadata.description,
          image: resolveIPFS(metadata.image),
        });
      }

      setNfts(nftList);
    } catch (error) {
      console.error("Error loading NFTs:", error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
  if (!walletConnected) return; // only load after wallet connected
  loadTasks(); // or loadNFTs()
}, [walletConnected]);


  return (
    <div>
      {loading && <p>Loading NFTs...</p>}
      {nfts.length === 0 && !loading && <p>No NFTs yet</p>}
      {nfts.map((n) => (
        <div key={n.id} className="nft-card">
          <img src={n.image} alt={n.name} width="150" />
          <div>{n.name}</div>
          <div>{n.description}</div>
        </div>
      ))}
    </div>
  );
}

