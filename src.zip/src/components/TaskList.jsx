import { useState, useEffect } from "react";
import { Contract } from "ethers";
import { TASKCHAIN_ABI, TASKCHAIN_ADDRESS } from "../utils/contractAbi";
import { getSigner } from "../utils/provider";

export default function TaskList({ walletConnected }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);

  async function loadTasks() {
    if (!walletConnected) return;

    try {
      setLoading(true);
      const signer = await getSigner();
      const contract = new Contract(TASKCHAIN_ADDRESS, TASKCHAIN_ABI, signer);

      const taskList = [];
      let id = 0;

      while (true) {
        try {
          const t = await contract.getTask(id);
          taskList.push({
            id: t.id.toNumber(),
            title: t.title,
            desc: t.description,
            done: t.done,
          });
          id++;
        } catch (e) {
          break; // No more tasks
        }
      }

      setTasks(taskList);
    } catch (error) {
      console.error("Error loading tasks:", error);
    } finally {
      setLoading(false);
    }
  }

 useEffect(() => {
  if (!walletConnected) return; // only load after wallet connected
  loadTasks(); // or loadNFTs()
}, [walletConnected]);

  return (
    <div>
      {loading && <p>Loading tasks...</p>}
      {tasks.map((task) => (
        <div key={task.id}>
          <h3>{task.title}</h3>
          <p>{task.desc}</p>
          <p>{task.done ? "Done ✅" : "Pending ❌"}</p>
        </div>
      ))}
      {tasks.length === 0 && !loading && <p>No tasks found</p>}
    </div>
  );
}

