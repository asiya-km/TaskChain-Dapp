import { ethers, BrowserProvider, Contract } from "ethers";
import {
  TASKCHAIN_ABI,
  TASKCHAIN_ADDRESS,
  SAVESMART_ABI,
  SAVESMART_ADDRESS,
  SAVETOKEN_ABI,
  SAVETOKEN_ADDRESS,
  REWARDNFT_ABI,
  REWARDNFT_ADDRESS
} from "../utils/contractAbi";

let cachedProvider = null;

// Connect wallet and get provider
export async function connectWallet() {
  if (!window.ethereum) throw new Error("MetaMask not installed");

  const provider = new BrowserProvider(window.ethereum);
  const accounts = await provider.send("eth_requestAccounts", []);
  if (!accounts || accounts.length === 0) {
    throw new Error("Wallet connection failed");
  }

  cachedProvider = provider;
  return provider;
}

// Get the cached provider or connect if missing
export async function getProvider() {
  if (cachedProvider) return cachedProvider;
  return await connectWallet();
}

// Get signer safely
export async function getSigner() {
  const provider = await getProvider();
  const signer = await provider.getSigner();
  if (!signer) throw new Error("Signer not initialized. Call connectWallet() first.");
  return signer;
}

// Contracts
export async function getTaskChainContract() {
  const signer = await getSigner();
  return new Contract(TASKCHAIN_ADDRESS, TASKCHAIN_ABI, signer);
}

export async function getSaveSmartContract() {
  const signer = await getSigner();
  return new Contract(SAVESMART_ADDRESS, SAVESMART_ABI, signer);
}

export async function getSaveTokenContract() {
  const signer = await getSigner();
  return new Contract(SAVETOKEN_ADDRESS, SAVETOKEN_ABI, signer);
}

export async function getRewardNFTContract() {
  const signer = await getSigner();
  return new Contract(REWARDNFT_ADDRESS, REWARDNFT_ABI, signer);
}

